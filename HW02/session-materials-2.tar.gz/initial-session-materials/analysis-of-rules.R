# Use arules package 
library(arules)

# Delete all variables and functions
rm(list=ls())

# Load the data
load("iris-discretised.Rdata")

# Find all rules using Apriori algorithm
# You can tune the behaviour of Apriori algorithm by changing thresholds 
parameters <- new("APparameter", support = 0.01, confidence = 0.7, target = "rules")

# You can control what elements appear on the left and right hand side
# This command is very brittle, default = "lhs" must be inside otherwise it does not work  
appearance <- list(rhs = c("Class=Iris-versicolor"),  default ="lhs")

rules <- apriori(iris.data, parameter = parameters, appearance = appearance)

# The Apriori algorithm returns a weird data structure. 
# There are several ways how to extract information out of it
# inspect, lhs, rhs, ... See the documentation about arules{rule-class} for more details
# str(rules)
inspect(rules[1])
inspect(lhs(rules[1]))
inspect(rhs(rules[1]))

inspect(rules[1:5]) 


# The next command converts rules into more accessible form which you can manipulate better 
rules.tbl <- as(rules, "data.frame")

# To sort rules according to the support you can use command sort
# The command sort with flag index.return returns also the permutation
sort(rules.tbl$support, decreasing = TRUE, index.return=TRUE)$ix


index <- sort(rules.tbl$support, decreasing = TRUE, index.return=TRUE)$ix

rules.tbl[index, 2:3]

# This command reorders rules according to support
rules <- rules[index]

# Since the arules does not provide a reasonable way to compute a cover of a rule, we have to 
# do it by brute force and it is ugly.
# 
# The function returns a True-False vector indicating which rows are matched by the lhs of the rule 

FindCover <- function(rule, dataset){
	# Extract the left hand side of the rule
	lhs.tbl <- itemInfo(lhs(rule))[which(as(lhs(rule), "matrix")[1, ] == 1), ]
	# Find the cover
	cover <- rep(TRUE, nrow(dataset))
	for(i in seq_len(nrow(lhs.tbl)))
	{
		cover <- cover & dataset[as.character(lhs.tbl$variables[i])] == as.character(lhs.tbl$levels[i])
	}
	return(cover)
}  

# Note that the cover of the first rule is larger than the support, since the the support counts only the true occurreces, 
# while the coverage contains all rows for which the left-hand side holds. 

which(FindCover(rules[1], iris.data))

sum(FindCover(rules[1], iris.data))/nrow(iris.data)
inspect(rules[1])

iris.data[which(FindCover(rules[1], iris.data)), ]

# Now observe that the summary cover of two rules is samller than the sum of individual covers 
cover1 <- FindCover(rules[1], iris.data)
cover2 <- FindCover(rules[2], iris.data)
(sum(cover1) + sum(cover2))/nrow(iris.data)
sum(cover1 | cover2)/nrow(iris.data) 


# Compute how does the fraction of covered rows increase with the number of rules
scover <- rep(FALSE, nrow(iris.data))
scoverage <- rep(NA, length(rules))
for(i in seq_len(length(rules)))
{
	scover <- scover | FindCover(rules[i], iris.data)
	scoverage[i] <- sum(scover)/nrow(iris.data) 
}

plot(scoverage, type="s")

# Continue with the exercise .... 
