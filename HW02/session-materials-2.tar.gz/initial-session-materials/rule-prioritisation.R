# Use rpart package 
library(base)
library(rpart)

# Delete all variables and functions
rm(list=ls())

# Load the data
load("iris-discretised.Rdata")

# Thy to fit a decision-tree on the data without no restrictions on the tree shape
control <- rpart.control(minbucket = 1, maxdepth = 30, cp = 0, maxcomplete = 0)
model <- rpart(Class ~ Sepal.Length + Sepal.Width + Petal.Length + Petal.Width, iris.data, control = control, method="class")

# The resulting decision tree can be viewed as follows
plot(model)
text(model, pretty = 0)


# Since rpart package does not provide a friendly interface for extracting rules for leaf nodes
# Then we must do it with brute force and its ugly 

# First we define a function that splits a text equation "Color=red,greeb,blue" into attribute name
# and value vector pair
 
DecodeTextEq <-function(text)
{
	tmp <- strsplit(text, split = "=", fixed = TRUE)[[1]]
	attribute <- tmp[1]
	values <- strsplit(tmp[2], split = ",", fixed = TRUE)[[1]] 
	return(list(attribute = attribute, values = values))
} 

# It works as follows 
DecodeTextEq("Color=red,greeb,blue")

# We can use this function to extract rules for each leaf node
# This is an ugly hack that you do not have to understand 
#
# The function returns two lists lhs and rhs where lhs[[i]] => rhs[[i]]
# corresponds to the i-th leaf node 

FindLeafRules <- function(model)
{
	leafs <- as.numeric(rownames(subset(model$frame, var == "<leaf>")))
	leaf.labels <- attr(model, "ylevels")[model$frame$yval]
	leaf.paths <- path.rpart(model, nodes = leafs, print.it = FALSE) 
	leaf.conditions <- lapply(leaf.paths, function(path){lapply(path[-1], DecodeTextEq)})
	return(list(lhs = leaf.conditions, rhs = leaf.labels))
} 

# Illustrative example. Lets find all rules corresponding to the model we learnt before
rules <- FindLeafRules(model)

# The left-hand side and right hand side of the first rule
rules$lhs[[1]]
rules$rhs[[1]]

# The left-hand side and right hand side of the second rule
rules$lhs[[2]]
rules$rhs[[2]]

# Note that the left-hand side consists of three different conditions which can be accessed as follows
# The first element in each row is an attribute name and the second element is the list of suitable values 
rules$lhs[[2]][[1]]
rules$lhs[[2]][[2]]
rules$lhs[[2]][[3]]


# Since we want to find out how many rows match the left-hand side of a rule we need a function
# that checks that all individual conditions are satisfied.
# The function takes in a lhs and a data frame and ouputs a true-false vector indicating which rows 
# satisfy the condition specified by lhs.  

MatchesOfLHS <- function(lhs, data)
{
	cover <- rep(TRUE, nrow(data))
	for(i in seq_along(lhs))
	{
		cover <- cover & (data[, lhs[[i]][[1]]] %in% lhs[[i]][[2]])
	}
	return(cover)		
}

# Illustrative examples
# To see which rows match the first rule, we can issue the following command 

which(MatchesOfLHS(rules$lhs[[1]], iris.data))

# For the second rule, we must issue the following command
which(MatchesOfLHS(rules$lhs[[2]], iris.data))

# To simplify a rule we can drop some assumptions, as in the following example
which(MatchesOfLHS(rules$lhs[[2]][-1], iris.data))
which(MatchesOfLHS(rules$lhs[[2]][-2], iris.data))
which(MatchesOfLHS(rules$lhs[[2]][-3], iris.data))

# Example of label prediction
predict(model,iris.data, type="class")