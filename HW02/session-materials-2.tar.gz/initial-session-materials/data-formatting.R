tbl <- read.csv("iris-original.csv")
tbl$Sepal.Length <- cut(tbl$Sepal.Length, breaks=5, labels=c("tiny", "small", "average", "large", "huge"))
tbl$Sepal.Width  <- cut(tbl$Sepal.Width,  breaks=5, labels=c("tiny", "small", "average", "large", "huge")) 
tbl$Petal.Length <- cut(tbl$Petal.Length, breaks=5, labels=c("tiny", "small", "average", "large", "huge")) 
tbl$Petal.Width  <- cut(tbl$Petal.Width,  breaks=5, labels=c("tiny", "small", "average", "large", "huge")) 
iris.data <- tbl
save(iris.data, file = "iris-discretised.Rdata")

