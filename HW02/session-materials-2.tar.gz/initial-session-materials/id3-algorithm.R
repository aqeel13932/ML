# Delete all variables and functions
rm(list=ls())

# Load the data
load("iris-discretised.Rdata")

x <- iris.data$Class

# A function for computing entropy for a vector of observations  
ComputeEntropy <- function(x)
{
	x <- as.character(x)
	probs <- ??
	entropy <- ??
	return(entropy)
}

# Test it 
ComputeEntropy(iris.data$Class)
ComputeEntropy(iris.data$Class[1:5])

# A function that splits target vector into two sub-vectors according to attribute value
# and threshold, and  computes the information gain corresponding to this split.
# Note that by convention we known  tiny < small < average < big < huge. Hence, we can 
# split the attribute values into two classes according to some threshold.
# 
# We can hardwire the corresponding partioning into a hash map
partitions <- list(tiny = c("tiny"))   
partitions[["small"]] <- c("tiny", "small")  
partitions[["average"]] <- c("tiny", "small", "average")  
partitions[["large"]] <- c("tiny", "small", "average", "large")  
partitions[["huge"]] <- c("tiny", "small", "average", "large", "huge")  

# and later use it to split the attribute vector into two classes
# For instance if we want to split the Sepal.Length according to the threshold average
# then we can use the following trick

iris.data$Sepal.Length
partitions[["average"]] 
iris.data$Sepal.Length %in% partitions[["average"]] 

attribute <-  iris.data$Sepal.Length %in% partitions[["average"]] 

# Use this knowledge to write the function that returns the best threshold and corresponding gain 

# To simplify function writing set arguments and then do online programming 
attribute <- iris.data$Sepal.Length
target <- iris.data$Class
threshold <- "average"

ComputeInformationGain <- function(attribute, threshold, target)
{
	
    pindex <-  attribute %in% partitions[[threshold]]	
	target1 <- target[pindex == TRUE]
	target2 <- target[pindex == FALSE]
    entropy1 <- ComputeEntropy(??) 
    entropy2 <- ComputeEntropy(??) 
    entropy  <- ComputeEntropy(??)
	gain <- ??
	return(list(threshold = threshold, gain = gain))
}

result <- ComputeInformationGain(iris.data$Sepal.Length, "average", iris.data$Class)


ComputeBestInformationGain <- function(attribute, target)
{
	thresholds <- c("tiny", "small", "average", "large", "huge")
	result <- ??
	for(threshold in thresholds)
	{
		??
	}
	return(result)
}

ComputeBestInformationGain(iris.data$Sepal.Length, iris.data$Class)

# Of course, you can also convert factors into number and do the thresholding afterwards
# For that you  should use as.numeric conversion. However, this is not obligatory 



# A function for printing indented text lines
TreeNodeLine <- function(text, level)
{
	cat(rep("\t", level))
	cat(text)
	cat("\n")
}

# A function for printing leaf node information
# Takes in vectors of targets from training and test data
 
PrintLeafNodeInfo <- function(train.target, test.target, level)
{
	TreeNodeLine("Leaf node", level)
	TreeNodeLine(sprintf("Size %.0f", length(train.target)), level)

	tmp <- table(train.target)/length(train.target) * 100
	decision <- names(tmp)[which.max(tmp)] 
	TreeNodeLine(sprintf("Decision: %s", decision), level)
	TreeNodeLine(sprintf("%s: %.1f %%", names(tmp), tmp), level)
	TreeNodeLine(sprintf("Training accuracy: %2.1f %%", tmp[decision]), level)

	tmp <- table(test.target)/length(test.target) * 100
	TreeNodeLine(sprintf("Test accuracy:     %2.1f %%", tmp[decision]), level)
}


# This is a blueprint for the recursive ID3 algorithm.  
# The recursion scheme is specified in such way that it is easy to draw the description  of a decision tree.   

RecursiveID3 <- function(tbl, rec.level = 0)
{
	# Find the best attribute for splitting
	# Iterate over all attributes
	for(i in c(1:4))
	{
	   #compute the gain for this column
	   result <- ComputeBestInformationGain(tbl[ , i], tbl[ , 5])	
	}
	
	# Draw some textual information about the decision tree
	TreeNodeLine("Some info", rec.level)
	
	# Split the data into two datasets according to the split criterion
	tbl1 <- ??

	# Call out recursively ID3 function
	RecursiveID3(tbl1, rec.level = rec.level + 1)	
	
	tbl2 <- ??

	# Call out recursively ID3 function
	RecursiveID3(tbl2, rec.level = rec.level + 1)	
}


# In order to work together with the training and test data you should use the following blueprint
# Note that you can find number of errors recursively provided that you return correct base values 
# in the leaf nodes
  
RecursiveID3 <- function(tbl.train, tbl.test rec.level = 0)
{
	# Find the best attribute for splitting
	??
	
	# Draw some textual information about the decision tree
	TreeNodeLine("Some info", rec.level)
	
	# Split the data into two datasets according to the split criterion
	tbl1.train <- ??
	tbl1.test <- ??

	# Call out recursively ID3 function
	errors1 <- RecursiveID3(tbl1.train, tbl1.test rec.level = rec.level + 1)	
	
	tbl2.train <- ??
	tbl2.test <- ??

	# Call out recursively ID3 function
	errors2 <- RecursiveID3(tbl2.train, tbl2.test rec.level = rec.level + 1)
	return(errors1 + errors2)	
}





