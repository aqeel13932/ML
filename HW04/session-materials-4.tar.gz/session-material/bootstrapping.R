rm(list=ls())

# Data source
# Simple data generator that generates data according to the formula
# Y = X^2 + sigma * N(0,1)
DataSource <- function(n, sigma = 0.1)
{
	X <- runif(n, min = 0, max = 1)
	Y <- X^2 - X + rnorm(n, sd = sigma)
	return(data.frame(X = X, Y = Y))
}



plot(DataSource(100), pch = 16)