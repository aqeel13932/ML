rm(list=ls())

# Formal definition of a data source
DataSource <- function(n)
{
	k <- floor(n/2)
	data <- data.frame(x1 = rnorm(k) - 1, x2 = rnorm(k) + 1, y = 1)
	data <- rbind(data, data.frame(x1 = rnorm(n - k) + 1, x2 = rnorm(n - k) - 1, y = -1))
	return(data)
}

# Lets see how the classification rule performs on a simple sample with threshold b=0
par(mfrow = c(2, 2))
data <- DataSource(100) 
plot(data[, -3], pch = 16, col = c("red", "yellow", "green")[2 + data$y], xlim=c(-3, 3), ylim = c(-3, 3), main = "True labels")
ypred <- sign(data$x2 - data$x1)
plot(data[, -3], pch = 16, col = c("red", "yellow", "green")[2 + ypred], xlim=c(-3, 3), ylim = c(-3, 3), main = "Predicted labels b = 0")
abline(a = 0, b = 1, col = "black", lwd = 2)

# Lets see how the classification rule performs on a simple sample with threshold b=1
ypred <- sign(data$x2 - data$x1 + 1)
plot(data[, -3], pch = 16, col = c("red", "yellow", "green")[2 + ypred], xlim=c(-3, 3), ylim = c(-3, 3), main = "Predicted labels b = 1")
abline(a = -1, b = 1, col = "black", lwd = 2)


# Lets see how the classification rule performs on a simple sample with threshold b=3
ypred <- sign(data$x2 - data$x1 + 3)
plot(data[, -3], pch = 16, col = c("red", "yellow", "green")[2 + ypred], xlim=c(-3, 3), ylim = c(-3, 3), main = "Predicted labels b = 3")
abline(a = -3, b = 1, col = "black", lwd = 2)

# Write functions for computing true positive rate

TruePositiveRate <- function(data, b)
{
	??
} 

FalsePositiveRate <- function(data, b)
{
	??
} 

TruePositiveRate(data, 0)
FalsePositiveRate(data, 0)

# Lets draw the ROC curve
TPR <- c()
FPR <- c()
plot(c(),c(), xlab = "False positive rate", ylab = "True positive rate", ylim = c(0, 1), xlim = c(0,1))
for(b in c(-5:5))
{
	TPR <- c(TPR, TruePositiveRate(data, b))
	FPR <- c(FPR, FalsePositiveRate(data, b))
}
points(FPR, TPR, pch = 16)
lines(FPR, TPR, lty = "dashed", col = "blue")

