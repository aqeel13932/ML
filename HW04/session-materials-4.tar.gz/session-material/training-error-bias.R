rm(list=ls())


# Datasource whith random target value
DataSource <- function(n)
{
	return(data.frame(x = floor(runif(n, 0, 8)), y = round(runif(n)) ))
}

# Note that there are 16 possible input output pairs with the same probability
plot(DataSource(100), pch = 16)


# Potential output functions and the simplest learning algoeithm

g0 <- function(x)
{
	return(0)
}

g8 <- function(x)
{
	return(1)
}

data <- DataSource(10)
LearningAlgoritm <- function(data)
{
	# We have to apply g0 to each element of the data$x
	# Since g0 is now written to handle vectors, we have to make it safe against vector inputs   
	y0 <- Vectorize(g0)(data$x)
	# Lets do the same for g8
	y1 <- Vectorize(g8)(data$x)
	
	if(sum(y0 == data$y) > sum(y1 == data$y)) return(g0)
	else return(g8) 
}

# Now the learning algorithm indeed returns the classifiaction rule 
LearningAlgoritm(data)

# Now you should just write the code for the sampling experiment




#
# Datasource with strongly biased target value
DataSourceWithStrongSignal <- function(n)
{
	return(data.frame(x = floor(runif(n, 0, 8)), y = as.numeric(runif(n) <= 0.9 )))
}

